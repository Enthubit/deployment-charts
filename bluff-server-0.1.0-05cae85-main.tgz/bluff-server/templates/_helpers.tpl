{{- define "bluff.name" -}}{{ .Chart.Name }}{{- end -}}
{{- define "bluff.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- end -}}
{{- define "bluff.labels" -}}
app.kubernetes.io/name: {{ include "bluff.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}
{{- define "bluff.selector" -}}
app.kubernetes.io/name: {{ include "bluff.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "bluff.image" -}}{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}{{- end -}}
{{- define "bluff.serviceAccount" -}}
{{- if .Values.serviceAccount.create -}}{{ default (include "bluff.fullname" .) .Values.serviceAccount.name }}
{{- else -}}{{ default "default" .Values.serviceAccount.name }}{{- end -}}
{{- end -}}
{{- define "bluff.tokenSecretName" -}}
{{- if .Values.tokenSecret.create -}}{{ include "bluff.fullname" . }}-token{{- else -}}{{ .Values.existingSecret }}{{- end -}}
{{- end -}}
{{- define "bluff.secretEnv" -}}
{{- if .Values.database.host }}
# The password comes from the database's own Secret; $(VAR) is filled in by Kubernetes.
- name: BLUFF_DB_PASSWORD
  valueFrom: { secretKeyRef: { name: {{ required "database.passwordSecret.name is needed with database.host" .Values.database.passwordSecret.name }}, key: {{ .Values.database.passwordSecret.key }} } }
- name: BLUFF_DATABASE_URL
  value: "host={{ .Values.database.host }} port={{ .Values.database.port }} user={{ .Values.database.user }} password=$(BLUFF_DB_PASSWORD) dbname={{ .Values.database.name }} sslmode={{ .Values.database.sslmode }}"
{{- else }}
- name: BLUFF_DATABASE_URL
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: database-url } }
{{- end }}
- name: BLUFF_TOKEN_SECRET
  valueFrom: { secretKeyRef: { name: {{ include "bluff.tokenSecretName" . }}, key: token-secret } }
- name: BLUFF_TOKEN_SECRET_PREVIOUS
  valueFrom: { secretKeyRef: { name: {{ include "bluff.tokenSecretName" . }}, key: token-secret-previous, optional: true } }
{{- end -}}
{{- define "bluff.migrateJobName" -}}
{{- if eq .Values.migrations.mode "job" -}}
{{ printf "%s-migrate-%s" (include "bluff.fullname" .) (.Values.image.tag | default .Chart.AppVersion | lower | replace "." "-" | replace "_" "-") | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ include "bluff.fullname" . }}-migrate{{- end -}}
{{- end -}}
