{{- define "crk.name" -}}{{ .Chart.Name }}{{- end -}}
{{- define "crk.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- end -}}
{{- define "crk.labels" -}}
app.kubernetes.io/name: {{ include "crk.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}
{{- define "crk.selector" -}}
app.kubernetes.io/name: {{ include "crk.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "crk.image" -}}{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}{{- end -}}
{{- define "crk.serviceAccount" -}}
{{- if .Values.serviceAccount.create -}}{{ default (include "crk.fullname" .) .Values.serviceAccount.name }}
{{- else -}}{{ default "default" .Values.serviceAccount.name }}{{- end -}}
{{- end -}}
{{- define "crk.tokenSecretName" -}}
{{- if .Values.tokenSecret.create -}}{{ include "crk.fullname" . }}-token{{- else -}}{{ .Values.existingSecret }}{{- end -}}
{{- end -}}
{{- define "crk.secretEnv" -}}
{{- if .Values.database.host }}
# The password comes from the database's own Secret; $(VAR) is filled in by Kubernetes.
- name: CRK_DB_PASSWORD
  valueFrom: { secretKeyRef: { name: {{ required "database.passwordSecret.name is needed with database.host" .Values.database.passwordSecret.name }}, key: {{ .Values.database.passwordSecret.key }} } }
- name: CRK_DATABASE_URL
  value: "host={{ .Values.database.host }} port={{ .Values.database.port }} user={{ .Values.database.user }} password=$(CRK_DB_PASSWORD) dbname={{ .Values.database.name }} sslmode={{ .Values.database.sslmode }}"
{{- else }}
- name: CRK_DATABASE_URL
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: database-url } }
{{- end }}
- name: CRK_TOKEN_SECRET
  valueFrom: { secretKeyRef: { name: {{ include "crk.tokenSecretName" . }}, key: token-secret } }
- name: CRK_TOKEN_SECRET_PREVIOUS
  valueFrom: { secretKeyRef: { name: {{ include "crk.tokenSecretName" . }}, key: token-secret-previous, optional: true } }
{{- end -}}
{{- define "crk.migrateJobName" -}}
{{- if eq .Values.migrations.mode "job" -}}
{{ printf "%s-migrate-%s" (include "crk.fullname" .) (.Values.image.tag | default .Chart.AppVersion | lower | replace "." "-" | replace "_" "-") | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ include "crk.fullname" . }}-migrate{{- end -}}
{{- end -}}
