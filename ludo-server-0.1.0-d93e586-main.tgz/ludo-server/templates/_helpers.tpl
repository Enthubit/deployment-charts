{{- define "ludo.name" -}}{{ .Chart.Name }}{{- end -}}
{{- define "ludo.fullname" -}}
{{- if contains .Chart.Name .Release.Name -}}{{ .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- end -}}
{{- define "ludo.labels" -}}
app.kubernetes.io/name: {{ include "ludo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | default .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end -}}
{{- define "ludo.selector" -}}
app.kubernetes.io/name: {{ include "ludo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "ludo.image" -}}{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}{{- end -}}
{{- define "ludo.serviceAccount" -}}
{{- if .Values.serviceAccount.create -}}{{ default (include "ludo.fullname" .) .Values.serviceAccount.name }}
{{- else -}}{{ default "default" .Values.serviceAccount.name }}{{- end -}}
{{- end -}}
{{- define "ludo.tokenSecretName" -}}
{{- if .Values.tokenSecret.create -}}{{ include "ludo.fullname" . }}-token{{- else -}}{{ .Values.existingSecret }}{{- end -}}
{{- end -}}
{{- define "ludo.secretEnv" -}}
{{- if .Values.database.host }}
# The password comes from the database's own Secret; $(VAR) is filled in by Kubernetes.
- name: LUDO_DB_PASSWORD
  valueFrom: { secretKeyRef: { name: {{ required "database.passwordSecret.name is needed with database.host" .Values.database.passwordSecret.name }}, key: {{ .Values.database.passwordSecret.key }} } }
- name: LUDO_DATABASE_URL
  value: "host={{ .Values.database.host }} port={{ .Values.database.port }} user={{ .Values.database.user }} password=$(LUDO_DB_PASSWORD) dbname={{ .Values.database.name }} sslmode={{ .Values.database.sslmode }}"
{{- else }}
- name: LUDO_DATABASE_URL
  valueFrom: { secretKeyRef: { name: {{ .Values.existingSecret }}, key: database-url } }
{{- end }}
- name: LUDO_TOKEN_SECRET
  valueFrom: { secretKeyRef: { name: {{ include "ludo.tokenSecretName" . }}, key: token-secret } }
- name: LUDO_TOKEN_SECRET_PREVIOUS
  valueFrom: { secretKeyRef: { name: {{ include "ludo.tokenSecretName" . }}, key: token-secret-previous, optional: true } }
{{- end -}}
{{- define "ludo.migrateJobName" -}}
{{- if eq .Values.migrations.mode "job" -}}
{{ printf "%s-migrate-%s" (include "ludo.fullname" .) (.Values.image.tag | default .Chart.AppVersion | lower | replace "." "-" | replace "_" "-") | trunc 63 | trimSuffix "-" }}
{{- else -}}{{ include "ludo.fullname" . }}-migrate{{- end -}}
{{- end -}}
